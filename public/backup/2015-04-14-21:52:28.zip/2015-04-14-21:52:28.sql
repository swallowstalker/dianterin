#
# TABLE STRUCTURE FOR: user_customer
#

CREATE TABLE `user_customer` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `name` text NOT NULL,
  `twitter` varchar(15) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '1',
  `deposit` int(11) NOT NULL DEFAULT '0',
  `register_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO user_customer (`id`, `email`, `password`, `name`, `twitter`, `phone`, `role`, `deposit`, `register_time`) VALUES (1, 'swallowstalker@gmail.com', '$2y$10$bUsy4fGDWGb7kafkSvf31OAPxX27.ZvbCUdOftWPxLRAXNUDpuV0i', 'Pulung', 'dianterin', '0123456789', 498, 11000, '2015-04-11 15:43:16');
INSERT INTO user_customer (`id`, `email`, `password`, `name`, `twitter`, `phone`, `role`, `deposit`, `register_time`) VALUES (41, 'g@t.ra', '$2y$10$MlD976oN0nMkTSJhdoznHeAgtm/aZJDBhKc5jufUij3e6Bbm7QiWO', 'Gatra', '1', '1', 498, 525, '2015-03-15 08:20:26');
INSERT INTO user_customer (`id`, `email`, `password`, `name`, `twitter`, `phone`, `role`, `deposit`, `register_time`) VALUES (64, 'ganteng@gmail.com', '$2y$10$60vhWyeM6UQURSuwlM0P6eRYMwQuG.eljvKej2cVkpo04vHcFvT4C', 'Ganteng', 'ganteng', '123456789', 1, 0, '2015-03-15 08:32:20');


#
# TABLE STRUCTURE FOR: transaction
#

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `restaurant` text NOT NULL,
  `menu` text NOT NULL,
  `price` int(11) NOT NULL,
  `delivery_cost` int(11) NOT NULL,
  `adjustment` int(11) NOT NULL,
  `adjustment_info` text NOT NULL,
  `final_cost` int(11) NOT NULL,
  `transaction_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `digunain` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `transaction_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `dipesenin` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (5, 1, 1517, 'Mie Ayam Apollo', 'Mie Ayam', 8000, 0, 0, '', 8000, '2015-01-27 05:55:12');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (6, 1, 1518, 'Warung Capuccino Cincau', 'Coklat Cincau', 5000, 0, 0, '', 5000, '2015-01-27 05:55:13');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (7, 1, 1519, 'Soto Mie', 'Soto Mie', 12000, 0, 0, '', 12000, '2015-01-30 07:56:28');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (8, 1, 1520, 'Sabana Fried Chicken', 'Dada + Nasi', 11000, 0, 2000, '', 13000, '2015-01-30 08:05:54');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (10, 1, 1521, 'Bakso Wonogiri', 'Ayam Kremes', 16000, 0, 2000, '', 18000, '2015-01-30 08:09:20');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (33, 7, 1526, 'Chicken Resto', 'Dada + Nasi (Paket Hemat Atas)', 12000, 1500, 0, '', 13500, '2015-02-13 04:48:58');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (35, 15, 1528, 'Soto Mie', 'Soto Mie', 24000, 1500, 0, '', 25500, '2015-02-13 04:48:58');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (39, 4, 1527, 'Gado-gado', 'Gado-gado', 10000, 1000, 0, '', 11000, '2015-02-14 10:41:52');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (40, 1, 1534, 'Sabana Fried Chicken', 'Dada + Nasi', 11000, 1000, 0, '', 12000, '2015-03-01 20:37:14');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (41, 4, 1535, 'Chicken Resto', 'Dada + Nasi (Paket Hemat Atas)', 12000, 1500, 0, '', 13500, '2015-03-01 20:37:14');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (42, 51, 1540, 'Sabana Fried Chicken', 'Dada + Nasi', 11000, 1000, 0, '', 12000, '2015-03-11 07:38:45');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (43, 42, 1541, 'Gado-gado', 'Gado-gado', 10000, 1000, 0, '', 11000, '2015-03-11 07:40:14');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (44, 22, 1542, 'Bakso Wonogiri', 'Ayam Kremes', 16000, 1000, 0, '', 17000, '2015-03-11 07:40:14');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (45, 1, 1548, 'Sabana Fried Chicken', 'Dada + Nasi', 11000, 1000, 0, '', 12000, '2015-03-22 13:13:31');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (46, 20, 1549, 'Chicken Resto', 'Dada + Nasi (Paket Hemat Atas)', 12000, 1500, 0, '', 13500, '2015-04-07 07:28:17');
INSERT INTO transaction (`id`, `user_id`, `order_id`, `restaurant`, `menu`, `price`, `delivery_cost`, `adjustment`, `adjustment_info`, `final_cost`, `transaction_time`) VALUES (47, 12, 1551, 'Bakso Wonogiri', 'Ayam Kremes', 16000, 1000, 0, '', 17000, '2015-04-07 07:28:17');


#
# TABLE STRUCTURE FOR: transaction_general
#

CREATE TABLE `transaction_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `movement` int(11) NOT NULL,
  `action` text NOT NULL,
  `transaction_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `transaction_general_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `digunain` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (6, 41, 1250, 'TRANSDEL: Vehicle Cost', '2015-04-07 07:29:51');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (7, 1, 375, 'TRANSDEL: Person Wages', '2015-04-07 07:29:52');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (8, 4, 375, 'TRANSDEL: Person Wages', '2015-04-07 07:29:52');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (9, 14, 125, 'TRANSDEL: Admin Wages', '2015-04-07 07:29:52');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (10, 1, 50000, 'DEPO: Tambah deposit', '2015-04-10 06:02:25');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (11, 1, -18500, 'ORDER: Payment for #1552', '2015-04-10 06:06:23');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (12, 1, 18500, 'REVERT: Revert payment for #1552', '2015-04-10 06:16:25');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (13, 1, 50335, 'INIT: Init user balance', '2015-04-11 15:43:16');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (14, 1, -50335, 'DEPO: Test', '2015-04-13 06:24:01');
INSERT INTO transaction_general (`id`, `user_id`, `movement`, `action`, `transaction_time`) VALUES (15, 1, 11000, 'DEPO: test', '2015-04-13 06:25:05');


#
# TABLE STRUCTURE FOR: transaction_asset
#

CREATE TABLE `transaction_asset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fund` int(11) NOT NULL,
  `transaction_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO transaction_asset (`id`, `fund`, `transaction_time`) VALUES (3, 525, '2015-03-11 07:51:55');
INSERT INTO transaction_asset (`id`, `fund`, `transaction_time`) VALUES (4, 375, '2015-04-07 07:29:52');


#
# TABLE STRUCTURE FOR: transaction_delivery
#

CREATE TABLE `transaction_delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `fund` int(11) NOT NULL,
  `transaction_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `transaction_delivery_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `digunain` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (9, 2, 30, 1250, '2015-03-11 07:51:55');
INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (10, 1, 41, 525, '2015-03-11 07:51:55');
INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (11, 1, 1, 525, '2015-03-11 07:51:55');
INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (12, 3, 14, 175, '2015-03-11 07:51:55');
INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (13, 2, 41, 1250, '2015-04-07 07:29:51');
INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (14, 1, 1, 375, '2015-04-07 07:29:52');
INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (15, 1, 4, 375, '2015-04-07 07:29:52');
INSERT INTO transaction_delivery (`id`, `status`, `user_id`, `fund`, `transaction_time`) VALUES (16, 3, 14, 125, '2015-04-07 07:29:52');


